<?php

return [
    'payments_deposit'      => 'Payments Deposits',
    'payments_withdrawal'   => 'Payments Withdrawals',
    'wallet_exchange'       => 'Wallet Exchange',
    'giftcard_trade'        => 'Giftcard Purchase',
    'disabled'              => 'Account verification is required.',
    'verification_required' => 'Account verification is required.',
    'limit_reached'         => 'You have reached the usage limit for this period.',
];
